<?php

namespace App\Http\Controllers;

use App\Http\Requests\UserRequest;
use App\Models\User;
use Exception;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class UserController
{
    /**
     * Returns a paginated list of users.
     * This method retrieves a paginated list of users from the database.
     * and returns it as a JSON response.
     * 
     *  @return \Illuminate\Http\JsonResponse
     */
    public function index():JsonResponse
    {
        // retrieves user data from the database, in descending order by paging
        $users = User::orderBy('id', 'DESC')->get(); 
        
        // checks if database is empty
        if(User::count() > 0){

            // return data
            return response()->json([
                'status' => true,
                'users' => $users,
            ], 200);

        }else{

            // return message
            return response()->json([
                'status' => false,
                'message' => 'Nenhum usuário encontrado!',
            ], 400);            
        }       
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Creates a new user with the data provided in the request.
     * 
     * @param  \App\Http\Requests\UserRequest  $request The request object containing the user data to be created.
     * @return \Illuminate\Http\JsonResponse
     */
    public function store(UserRequest $request):JsonResponse
    {
        // Test if you are receiving values from the form
        // dd($request);

        // Start transaction
        DB::beginTransaction();

        // create a hash
        $string = md5(time() . rand(0, 9999) . time());

        // remove periods and dashes and slashes and commas from the hash
        $hash = str_replace(['.', '-', '/', ','], '', $string);       

        try{

            // Register user in the database
            $user = User::create([
                'name' => $request->name,
                'email' => $request->email,
                'password' => $request->password,
                'hash' => $hash,
            ]);

            // Operation completed successfully
            DB::commit();

            // Returns the data of the created user and a success message with status 201
            return response()->json([
                'status' => true,
                'user' => $user,
                'message' => "Usuário cadastrado com sucesso!",
            ], 201);

        }catch(Exception $e){

            // Operation not completed successfully
            DB::rollBack();

            // Returns an error message with status 400
            return response()->json([
                'status' => false,
                'message' => 'Usuário não cadastrado!',
            ], 400); 
        }
    }

    /**
     * Displays details of a specific user.
     * 
     * This method returns the details of a specific user in JSON format.
     * @param  \App\Models\User  $user The user object to display
     * @return \Illuminate\Http\JsonResponse
     */
    public function show($user):JsonResponse
    {
        // Retrieve user from database
        $result = User::where('hash', $user)->get();

        if(!empty($result[0])){

            // return data
            return response()->json([
                'status' => true,
                'user' => $result,
            ], 200);

        }else{

            // return message
            return response()->json([
                'status' => false,
                'message' => 'Nenhum usuário encontrado!',
            ], 400);       
        }
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(User $user)
    {
        //
    }

    /**
     * Update an existing user's data based on the data provided in the request.
     * 
     * @param  \App\Http\Requests\UserRequest  $request The request object containing the user data to be updated.
     * @param  \App\Models\User  $user The user to update.
     * @return \Illuminate\Http\JsonResponse
     */
    public function update(Request $request, $user):JsonResponse
    {
        // Test if you are receiving values from the form
        // dd($request);

        // Retrieve user from database
        $resultUser = User::where('hash', $user)->first();

        // Start the transaction
        DB::beginTransaction();

        try{

            // Edit the record in the database
            $resultUser->update([
                'name' => $request->name,
                'email' => $request->email,
                'password' => $request->password,
            ]);

            // Operation completed successfully
            DB::commit();

            // Returns the edited user data and a success message with status 200
            return response()->json([
                'status' => true,
                'user' => $resultUser,
                'message' => "Usuário editado com sucesso!",
            ], 200);

        }catch(Exception $e) {

            // Operation does not complete successfully
            DB::rollBack();

            // Returns an error message with status 400
            return response()->json([
                'status' => false,
                'message' => "Usuário não editado!",
            ], 400);
        }
    }

    /**
     * Delete user in database.
     * 
     * @param  \App\Models\User  $user The user to be deleted.
     * @return \Illuminate\Http\JsonResponse
     */
    public function destroy($user):JsonResponse
    {
        // Retrieve user from database
        $resultUser = User::where('hash', $user)->first();

        try{
            
            // Delete the record in the database
            $resultUser->delete();

            // Returns the deleted user data and a success message with status 200
            return response()->json([
                'status' => true,
                'user' => $resultUser,
                'message' => "Usuário apagado com sucesso!",
            ], 200);


        }catch(Exception $e) {

            // Returns an error message with status 400
            return response()->json([
                'status' => false,
                'message' => "Usuário não apagado!",
            ], 400);
        }
    }
}
