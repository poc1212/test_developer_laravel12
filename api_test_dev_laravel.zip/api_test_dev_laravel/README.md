## Requisitos

* PHP 8.3.6 ou superior
* MySQL 8 ou superior
* Composer

## Como rodar o projeto baixado

Duplicar o arquivo ".env.example" e renomear para ".env".<br>
Alterar no arquivo .env as credenciais do banco de dados<br>

## Instalar as dependências do PHP
```
composer install
```

## criar o projeto
## Como criar o projeto com Laravel
```
composer create-project laravel/laravel .
```

## Gerar a chave no arquivo .env
```
php artisan key:generate
```

## Executar as migration
```
php artisan migrate
```

## Iniciar o projeto criado com Laravel
```
php artisan serve
```

## Para acessar a API, é recomendado utilizar o Insomnia para simular requisições à API.
```
http://127.0.0.1:8000/api/users
```

## Como criar o arquivo de rotas para API no Laravel 12
```
php artisan install:api
```

## Como criar o Request com artisan no Laravel 12
```
php artisan make:request NomeDoRequest
php artisan make:request UserRequest
```