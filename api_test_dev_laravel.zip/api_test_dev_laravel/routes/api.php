<?php

use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Route;

// Route::get('/users', [UserController::class, 'index']); // GET - http://127.0.0.1:8000/api/users?page=1 - to implement pagination
Route::get('/users', [UserController::class, 'index']); // GET - http://127.0.0.1:8000/api/users
Route::get('/users/{user}', [UserController::class, 'show']); // GET - http://127.0.0.1:8000/api/users/723ce2a12326c9d9a85fc404598f2e08
Route::post('/users', [UserController::class, 'store']); // POST - http://127.0.0.1:8000/api/users
Route::put('/users/{user}', [UserController::class, 'update']); // PUT - http://127.0.0.1:8000/api/users/723ce2a12326c9d9a85fc404598f2e08
Route::delete('/users/{user}', [UserController::class, 'destroy']); // DELETE - http://127.0.0.1:8000/api/users/723ce2a12326c9d9a85fc404598f2e08


